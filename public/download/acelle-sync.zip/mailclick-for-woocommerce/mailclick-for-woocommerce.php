<?php
/*
Plugin Name: MailClick for WooCommerce
Description: Integrare între WooCommerce și platforma ta de Email Marketing.
Version: 1.0.3
Author: DigiClick
*/

if (!defined('ABSPATH')) {
    exit;
}

// Înregistrăm REST API endpoints
require_once plugin_dir_path(__FILE__) . 'includes/api.php';

// Adăugăm o pagină în Admin
require_once plugin_dir_path(__FILE__) . 'includes/admin-page.php';
