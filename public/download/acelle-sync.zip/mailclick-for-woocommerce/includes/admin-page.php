<?php

add_action('admin_menu', function () {
    add_menu_page(
        'MailClick for WooCommerce',
        'MailClick Connect',
        'manage_options',
        'mailclick-connect',
        'mailclick_admin_page_content',
        'dashicons-email-alt',
        58
    );
});

function mailclick_admin_page_content()
{
    $endpoint_url = site_url('/wp-json/mailclick/v1/endpoint');
    ?>
    <div class="wrap">
        <h1>MailClick for WooCommerce</h1>
        <p>Folosește acest URL pentru a conecta magazinul tău la platforma MailClick:</p>
        <input type="text" value="<?php echo esc_url($endpoint_url); ?>" style="width: 100%;" readonly />
        <p><strong>Instrucțiuni:</strong> Copiază acest link și lipește-l în platforma ta de Email Marketing unde îți cere <code>Connect URL</code>.</p>
    </div>
    <?php
}
