<?php

add_action('rest_api_init', function () {
    register_rest_route('mailclick/v1', '/endpoint', [
        'methods' => 'GET',
        'callback' => 'mailclick_api_handler',
        'permission_callback' => '__return_true'
    ]);
});

function mailclick_api_handler(\WP_REST_Request $request)
{
    $action = $request->get_param('action');

    if (!$action) {
        // Pasul 1: verificare conexiune
        return new WP_REST_Response([
            'status' => 'ok',
            'message' => 'Connected successfully to WooCommerce store.'
        ], 200);
    }

    if ($action === 'shop_info') {
        // Pasul 2: trimitem informații despre magazin
        return new WP_REST_Response([
            'name' => get_bloginfo('name'),
            'url' => get_bloginfo('url'),
            'description' => get_bloginfo('description'),
            'admin_email' => get_bloginfo('admin_email'),
        ], 200);
    }

    if ($action === 'list') {
        // Pasul 3: listăm produsele
        $products = [];

        $query = new WP_Query([
            'post_type' => 'product',
            'posts_per_page' => 100,
        ]);

        foreach ($query->posts as $post) {
            $product = wc_get_product($post->ID);
            $image = get_the_post_thumbnail_url($post->ID, 'full');

            $categories = wp_get_post_terms($post->ID, 'product_cat');
            $category_ids = [];

            foreach ($categories as $category) {
                $category_ids[] = $category->term_id;
            }

            $products[] = [
                'id' => $post->ID,
                'name' => $post->post_title,
                'description' => $post->post_content,
                'image' => $image ? $image : null,
                'category_id' => json_encode($category_ids),
                'meta' => json_encode(get_post_meta($post->ID)),
                'price' => $product->get_price(),
                'status' => $product->get_status(),
                'stock' => $product->get_stock_quantity(),
            ];
        }

        return new WP_REST_Response($products, 200);
    }

    // Dacă action necunoscut
    return new WP_REST_Response([
        'error' => 'Unknown action'
    ], 400);
}